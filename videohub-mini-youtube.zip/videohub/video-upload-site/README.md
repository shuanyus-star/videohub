# VideoHub Mini YouTube

Starter full-stack platform: accounts, dashboard, multipart direct upload, public/unlisted/private visibility, video player, search, likes, comments, views, delete/edit API, PostgreSQL and S3/R2-compatible storage.

## Setup
1. Install Node.js 20+ and PostgreSQL.
2. Copy `.env.example` to `.env` and fill DATABASE_URL + S3/R2 credentials.
3. `npm install`
4. `npm run prisma:generate`
5. `npm run prisma:migrate -- --name init`
6. `npm run dev`
7. Open `http://localhost:3000`.

## Large uploads
The browser uploads in 10 MB multipart chunks directly to S3/R2. The application server only signs parts, so the video does not pass through Next.js. The current UI is sequential and suitable as an MVP; production can add parallel chunks/retry/resume.

## HLS processing
`worker/process-video.ts` is an integration starting point. Install FFmpeg and connect it to a queue after upload completion. For production, generate 1080p/720p/480p HLS, thumbnail, duration and update `hlsKey`/`thumbnailKey`.

## Production checklist
HTTPS, rate limiting, email verification, CSRF strategy, virus/content scanning, abuse reporting, storage lifecycle rules, CDN, signed playback URLs, transcoding queue, retryable multipart uploads, admin moderation, backups and monitoring.
