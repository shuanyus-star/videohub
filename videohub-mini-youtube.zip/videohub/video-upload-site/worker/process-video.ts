/** Optional worker: downloads a READY/PROCESSING object, creates thumbnail + HLS with FFmpeg, then uploads outputs.
 * Run with: npm run worker -- <videoId>. Requires ffmpeg and bucket credentials.
 * For production, connect this to a queue (BullMQ/SQS/Cloudflare Queues) after multipart completion.
 */
import {prisma} from '../lib/prisma'; import {signedGet} from '../lib/s3'; import {execFileSync} from 'child_process'; import fs from 'fs';
const id=process.argv[2]; if(!id)throw new Error('videoId required');
(async()=>{const v=await prisma.video.findUnique({where:{id}});if(!v)throw new Error('not found');const url=await signedGet(v.objectKey,3600);const dir='/tmp/videohub-'+id;fs.mkdirSync(dir,{recursive:true});execFileSync('curl',['-L',url,'-o',dir+'/source']);execFileSync('ffmpeg',['-y','-i',dir+'/source','-ss','00:00:01','-frames:v','1',dir+'/thumb.jpg']);execFileSync('ffmpeg',['-y','-i',dir+'/source','-codec:v','libx264','-codec:a','aac','-hls_time','6','-hls_playlist_type','vod',dir+'/index.m3u8']);await prisma.video.update({where:{id},data:{status:'READY'}});console.log('Processed',id,'Upload HLS/thumbnail to your object storage here.');})().finally(()=>prisma.$disconnect());
