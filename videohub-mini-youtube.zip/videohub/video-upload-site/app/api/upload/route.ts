import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { presignedUploadUrl } from '@/lib/s3';
const schema=z.object({title:z.string().min(1).max(150),description:z.string().max(5000).optional(),fileName:z.string().min(1),fileSize:z.number().positive(),mimeType:z.string().startsWith('video/')});
export async function POST(req:NextRequest){try{const body=schema.parse(await req.json());const max=20*1024**3;if(body.fileSize>max)return NextResponse.json({error:'Maksimum 20 GB per file.'},{status:413});const id=crypto.randomUUID();const safe=body.fileName.replace(/[^a-zA-Z0-9._-]/g,'_');const key=`videos/${id}-${safe}`;const video=await prisma.video.create({data:{id,title:body.title,description:body.description||'',objectKey:key,originalName:body.fileName,size:BigInt(body.fileSize),mimeType:body.mimeType}});const uploadUrl=await presignedUploadUrl(key,body.mimeType);return NextResponse.json({id:video.id,uploadUrl,key});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400})}}
